Hybrid TabNet–CNN Framework

Reference implementation for the hybrid TabNet–CNN model used in the
associated Scientific Reports manuscript.
