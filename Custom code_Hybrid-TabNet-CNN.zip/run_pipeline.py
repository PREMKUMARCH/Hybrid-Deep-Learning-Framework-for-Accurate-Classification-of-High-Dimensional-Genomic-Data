import pandas as pd
import torch
from sklearn.model_selection import train_test_split

from src.data_preprocessing import preprocess_data
from src.tabnet_feature_selector import train_tabnet
from src.afr_module import adaptive_feature_refinement
from src.cnn_model import CNNClassifier
from src.train_cnn import train_model
from src.evaluate import evaluate

X = pd.read_csv("data/gene_expression.csv").values
y = pd.read_csv("data/labels.csv").values.ravel()

X = preprocess_data(X)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, stratify=y, random_state=42
)

tabnet = train_tabnet(X_train, y_train, X_test, y_test)

X_train_ref, idx = adaptive_feature_refinement(X_train, tabnet.feature_importances_)
X_test_ref = X_test[:, idx]

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNNClassifier(X_train_ref.shape[1], len(set(y))).to(device)

model = train_model(
    model,
    torch.tensor(X_train_ref, dtype=torch.float32).to(device),
    torch.tensor(y_train, dtype=torch.long).to(device)
)

metrics = evaluate(
    model,
    torch.tensor(X_test_ref, dtype=torch.float32).to(device),
    y_test
)

print(metrics)
