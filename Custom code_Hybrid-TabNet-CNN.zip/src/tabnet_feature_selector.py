import torch
from pytorch_tabnet.tab_model import TabNetClassifier

def train_tabnet(X_train, y_train, X_val, y_val):
    model = TabNetClassifier(
        n_d=64,
        n_a=64,
        n_steps=5,
        gamma=1.5,
        lambda_sparse=1e-4,
        optimizer_fn=torch.optim.Adam,
        optimizer_params=dict(lr=2e-2),
        mask_type="sparsemax"
    )
    model.fit(
        X_train=X_train,
        y_train=y_train,
        eval_set=[(X_val, y_val)],
        eval_metric=["accuracy"],
        max_epochs=200,
        patience=30,
        batch_size=1024,
        virtual_batch_size=128
    )
    return model
