import numpy as np

def adaptive_feature_refinement(X, importance, top_k=512):
    indices = np.argsort(importance)[::-1][:top_k]
    return X[:, indices], indices
